from unittest import TestCase
from corneredbeast.vincent.main.db_handler import Database

# coding:utf-8
class TestDatabase(TestCase):
    def test_query(self):
        db = Database()



