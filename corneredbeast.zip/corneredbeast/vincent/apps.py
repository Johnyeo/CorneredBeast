from django.apps import AppConfig


class RtxspyConfig(AppConfig):
    name = 'corneredbeast.vincent'
